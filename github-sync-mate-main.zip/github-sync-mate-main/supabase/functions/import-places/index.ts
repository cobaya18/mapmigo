import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { parse } from "https://deno.land/std@0.168.0/encoding/csv.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// Restrict CORS to only the app domain
const ALLOWED_ORIGINS = [
  "https://tnspumkhacfzcagfeywq.lovableproject.com",
  "https://lovable.dev",
];

function getCorsHeaders(origin: string | null): Record<string, string> {
  // Check if the origin is allowed
  const allowedOrigin = origin && ALLOWED_ORIGINS.some(allowed => 
    origin === allowed || origin.endsWith('.lovableproject.com') || origin.endsWith('.lovable.dev')
  ) ? origin : ALLOWED_ORIGINS[0];
  
  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
}

serve(async (req) => {
  const origin = req.headers.get("origin");
  const corsHeaders = getCorsHeaders(origin);

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Authentication check - require valid JWT
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(JSON.stringify({ error: "Unauthorized - no token provided" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify the JWT and get user
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      console.error("Auth error:", authError?.message || "No user found");
      return new Response(JSON.stringify({ error: "Unauthorized - invalid token" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    console.log(`Import initiated by user: ${user.id}`);

    const { csvData } = await req.json();

    if (!csvData || typeof csvData !== "string") {
      return new Response(JSON.stringify({ error: "No CSV data provided" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Robust CSV parse (supports quoted fields + embedded newlines)
    const rows = (await parse(csvData, {
      skipFirstRow: false,
      separator: ",",
      trimLeadingSpace: true,
    })) as string[][];

    if (rows.length < 2) {
      return new Response(JSON.stringify({ error: "CSV has no data rows" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const headers = rows[0].map((h) => h.trim());

    const places: Record<string, unknown>[] = [];
    for (let i = 1; i < rows.length; i++) {
      const values = rows[i];
      if (!values || values.length === 0) continue;

      const place: Record<string, unknown> = {};
      for (let j = 0; j < headers.length; j++) {
        const key = headers[j];
        const raw = values[j] ?? "";
        const value = typeof raw === "string" ? raw.trim() : String(raw);

        if (key === "latitude" || key === "longitude") {
          place[key] = value ? Number(value) : null;
        } else {
          place[key] = value || null;
        }
      }

      // required fields
      if (place.title && place.category && place.latitude && place.longitude) {
        places.push(place);
      }
    }

    // Insert in batches
    const batchSize = 200;
    let insertedCount = 0;

    for (let i = 0; i < places.length; i += batchSize) {
      const batch = places.slice(i, i + batchSize);
      const { data, error } = await supabase.from("places").insert(batch).select("id");
      if (error) throw error;
      insertedCount += data?.length ?? 0;
    }

    console.log(`Successfully imported ${insertedCount} places by user ${user.id}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: `Successfully imported ${insertedCount} places`,
        count: insertedCount,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error: unknown) {
    console.error("Import error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
