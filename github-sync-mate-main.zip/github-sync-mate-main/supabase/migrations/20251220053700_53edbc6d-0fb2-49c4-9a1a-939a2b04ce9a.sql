-- Add missing RLS policies for profiles table
-- INSERT policy (defense-in-depth - profiles are created by trigger, but this prevents direct inserts)
CREATE POLICY "Users can insert their own profile"
ON public.profiles
FOR INSERT
WITH CHECK (auth.uid() = id);

-- DELETE policy (prevent profile deletion - users should use account deletion instead)
CREATE POLICY "Users cannot delete profiles directly"
ON public.profiles
FOR DELETE
USING (false);

-- Add missing UPDATE policy for saved_places table
CREATE POLICY "Users can update their saved places"
ON public.saved_places
FOR UPDATE
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);