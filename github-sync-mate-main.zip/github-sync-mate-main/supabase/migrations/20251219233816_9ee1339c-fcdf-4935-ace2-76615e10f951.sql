-- Create places table with all specified columns
CREATE TABLE public.places (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  region TEXT,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  description TEXT,
  image_url TEXT,
  google_maps_url TEXT,
  cost TEXT,
  website_url TEXT,
  parking TEXT,
  municipality TEXT,
  access TEXT,
  image_credit TEXT,
  type TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.places ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access (places are viewable by everyone)
CREATE POLICY "Places are viewable by everyone" 
ON public.places 
FOR SELECT 
USING (true);

-- Create index for common queries
CREATE INDEX idx_places_category ON public.places(category);
CREATE INDEX idx_places_region ON public.places(region);
CREATE INDEX idx_places_municipality ON public.places(municipality);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_places_updated_at
BEFORE UPDATE ON public.places
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();