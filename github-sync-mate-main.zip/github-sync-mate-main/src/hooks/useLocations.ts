import { useQuery } from '@tanstack/react-query';
import { useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Location } from '@/types/location';

interface UseLocationsOptions {
  searchQuery?: string;
  selectedCategories?: string[];
  selectedRegions?: string[];
}

async function fetchLocations(): Promise<Location[]> {
  const { data, error } = await supabase
    .from('places')
    .select('*')
    .order('title', { ascending: true });

  if (error) {
    throw new Error(error.message);
  }

  return data as Location[];
}

export function useLocations(options: UseLocationsOptions = {}) {
  const { searchQuery = '', selectedCategories = [], selectedRegions = [] } = options;

  const { data: allLocations = [], isLoading, error } = useQuery({
    queryKey: ['places'],
    queryFn: fetchLocations,
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  // Memoize filtered locations to prevent recalculation on every render
  const filteredLocations = useMemo(() => {
    return allLocations.filter((location) => {
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesSearch =
          location.title.toLowerCase().includes(query) ||
          location.description?.toLowerCase().includes(query) ||
          location.region?.toLowerCase().includes(query) ||
          location.municipality?.toLowerCase().includes(query);
        if (!matchesSearch) return false;
      }

      // Category filter
      if (selectedCategories.length > 0) {
        if (!selectedCategories.includes(location.category)) return false;
      }

      // Region filter
      if (selectedRegions.length > 0) {
        if (!location.region || !selectedRegions.includes(location.region)) return false;
      }

      return true;
    });
  }, [allLocations, searchQuery, selectedCategories, selectedRegions]);

  return {
    locations: filteredLocations,
    allLocations,
    isLoading,
    error,
  };
}
