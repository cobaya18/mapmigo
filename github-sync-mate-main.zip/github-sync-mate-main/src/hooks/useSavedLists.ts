import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface SavedList {
  id: string;
  user_id: string;
  name: string;
  type: 'want_to_go' | 'been_there' | 'collection';
  icon: string | null;
  created_at: string;
}

export function useSavedLists() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['saved-lists', user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from('saved_lists')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      return data as SavedList[];
    },
    enabled: !!user,
  });
}

export function useCreateList() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({ name, icon }: { name: string; icon?: string }) => {
      if (!user) throw new Error('Must be logged in');
      const { data, error } = await supabase
        .from('saved_lists')
        .insert({
          user_id: user.id,
          name,
          type: 'collection',
          icon: icon || '📁',
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['saved-lists'] });
    },
  });
}

export function useDeleteList() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (listId: string) => {
      const { error } = await supabase
        .from('saved_lists')
        .delete()
        .eq('id', listId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['saved-lists'] });
      queryClient.invalidateQueries({ queryKey: ['saved-places'] });
    },
  });
}
