import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import type { Location } from '@/types/location';

export interface SavedPlace {
  id: string;
  list_id: string;
  place_id: string;
  user_id: string;
  saved_at: string;
  place?: Location;
}

export function useSavedPlaces(listId?: string) {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['saved-places', user?.id, listId],
    queryFn: async () => {
      if (!user) return [];
      
      let query = supabase
        .from('saved_places')
        .select(`
          *,
          place:places(*)
        `)
        .eq('user_id', user.id);

      if (listId) {
        query = query.eq('list_id', listId);
      }

      const { data, error } = await query.order('saved_at', { ascending: false });

      if (error) throw error;
      return data as SavedPlace[];
    },
    enabled: !!user,
  });
}

export function useAllUserSavedPlaces() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['all-saved-places', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('saved_places')
        .select('place_id, list_id')
        .eq('user_id', user.id);

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });
}

export function useSavePlace() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({ placeId, listId }: { placeId: string; listId: string }) => {
      if (!user) throw new Error('Must be logged in');
      
      const { data, error } = await supabase
        .from('saved_places')
        .insert({
          place_id: placeId,
          list_id: listId,
          user_id: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['saved-places'] });
      queryClient.invalidateQueries({ queryKey: ['all-saved-places'] });
    },
  });
}

export function useRemoveSavedPlace() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ placeId, listId }: { placeId: string; listId: string }) => {
      const { error } = await supabase
        .from('saved_places')
        .delete()
        .eq('place_id', placeId)
        .eq('list_id', listId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['saved-places'] });
      queryClient.invalidateQueries({ queryKey: ['all-saved-places'] });
    },
  });
}
