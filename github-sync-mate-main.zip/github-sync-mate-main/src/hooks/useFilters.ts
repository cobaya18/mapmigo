import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export function useFilters() {
  const { data: categories = [], isLoading: loadingCategories } = useQuery({
    queryKey: ['filter-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('places')
        .select('category')
        .order('category');
      
      if (error) throw error;
      
      // Get unique categories
      const uniqueCategories = [...new Set(data.map(d => d.category))].filter(Boolean);
      return uniqueCategories as string[];
    },
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  const { data: regions = [], isLoading: loadingRegions } = useQuery({
    queryKey: ['filter-regions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('places')
        .select('region')
        .not('region', 'is', null)
        .order('region');
      
      if (error) throw error;
      
      // Get unique regions
      const uniqueRegions = [...new Set(data.map(d => d.region))].filter(Boolean);
      return uniqueRegions as string[];
    },
    staleTime: 1000 * 60 * 5, // Cache for 5 minutes
  });

  return {
    categories,
    regions,
    isLoading: loadingCategories || loadingRegions,
  };
}
