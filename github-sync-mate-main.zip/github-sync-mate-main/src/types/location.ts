export interface Location {
  id: string;
  title: string;
  description: string | null;
  category: string;
  region: string | null;
  latitude: number;
  longitude: number;
  image_url: string | null;
  google_maps_url: string | null;
  cost: string | null;
  website_url: string | null;
  parking: string | null;
  municipality: string | null;
  access: string | null;
  image_credit: string | null;
  type: string | null;
  created_at: string;
  updated_at: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface Region {
  id: string;
  name: string;
}

export type CategoryKey = 
  | 'beach'
  | 'food'
  | 'nature'
  | 'culture'
  | 'adventure'
  | 'nightlife'
  | 'shopping'
  | 'lodging';

export const CATEGORIES: Record<CategoryKey, Category> = {
  beach: { id: 'beach', name: 'Beaches', icon: 'Waves', color: 'category-beach' },
  food: { id: 'food', name: 'Food & Drink', icon: 'UtensilsCrossed', color: 'category-food' },
  nature: { id: 'nature', name: 'Nature', icon: 'TreePine', color: 'category-nature' },
  culture: { id: 'culture', name: 'Culture', icon: 'Landmark', color: 'category-culture' },
  adventure: { id: 'adventure', name: 'Adventure', icon: 'Mountain', color: 'category-adventure' },
  nightlife: { id: 'nightlife', name: 'Nightlife', icon: 'Music', color: 'category-nightlife' },
  shopping: { id: 'shopping', name: 'Shopping', icon: 'ShoppingBag', color: 'category-shopping' },
  lodging: { id: 'lodging', name: 'Lodging', icon: 'Bed', color: 'category-lodging' },
};

export const REGIONS = [
  'San Juan',
  'Ponce',
  'Mayagüez',
  'Aguadilla',
  'Rincón',
  'Fajardo',
  'Vieques',
  'Culebra',
  'Luquillo',
  'Carolina',
  'Bayamón',
  'Caguas',
  'Humacao',
  'Arecibo',
  'Cabo Rojo',
];
