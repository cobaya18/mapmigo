import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useFilters } from '@/hooks/useFilters';
import { Skeleton } from '@/components/ui/skeleton';
import { getCategoryColor, getCategoryEmoji } from '@/lib/categoryConfig';

interface FiltersSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  selectedCategories: string[];
  onCategoryChange: (categories: string[]) => void;
  selectedRegions: string[];
  onRegionChange: (regions: string[]) => void;
  locationCount: number;
}

export function FiltersSidebar({
  isOpen,
  onClose,
  selectedCategories,
  onCategoryChange,
  selectedRegions,
  onRegionChange,
  locationCount,
}: FiltersSidebarProps) {
  const { categories, regions, isLoading } = useFilters();

  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      onCategoryChange(selectedCategories.filter((c) => c !== category));
    } else {
      onCategoryChange([...selectedCategories, category]);
    }
  };

  const toggleRegion = (region: string) => {
    if (selectedRegions.includes(region)) {
      onRegionChange(selectedRegions.filter((r) => r !== region));
    } else {
      onRegionChange([...selectedRegions, region]);
    }
  };

  const selectAllCategories = () => {
    onCategoryChange([]);
  };

  const selectAllRegions = () => {
    onRegionChange([]);
  };

  const clearAllFilters = () => {
    onCategoryChange([]);
    onRegionChange([]);
  };

  const hasActiveFilters = selectedCategories.length > 0 || selectedRegions.length > 0;
  const activeFilterCount = selectedCategories.length + selectedRegions.length;

  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Header */}
      <div className="p-4 border-b border-sidebar-border">
        <h2 className="font-semibold text-sidebar-foreground text-lg">Filters</h2>
        <p className="text-sm text-muted-foreground">
          {locationCount} results • {hasActiveFilters ? `${activeFilterCount} filter${activeFilterCount !== 1 ? 's' : ''} active` : 'No filters active'}
        </p>
      </div>

      {/* Filters */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-6">
          {/* Categories */}
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-3">Filter by Category</p>
            <div className="grid grid-cols-2 gap-2">
              {/* All button */}
              <button
                onClick={selectAllCategories}
                className={cn(
                  'px-3 py-2 rounded-md text-sm font-medium transition-all text-left',
                  'border',
                  selectedCategories.length === 0
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-transparent text-sidebar-foreground border-border hover:bg-sidebar-accent'
                )}
              >
                All
              </button>
              
              {isLoading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))
              ) : (
                categories.map((category) => {
                  const isSelected = selectedCategories.includes(category);
                  const color = getCategoryColor(category);
                  const emoji = getCategoryEmoji(category);
                  
                  return (
                    <button
                      key={category}
                      onClick={() => toggleCategory(category)}
                      className={cn(
                        'px-3 py-2 rounded-md text-sm font-medium transition-all text-left',
                        'border flex items-center gap-2',
                        isSelected
                          ? 'bg-sidebar-accent border-primary'
                          : 'bg-transparent text-sidebar-foreground border-border hover:bg-sidebar-accent'
                      )}
                    >
                      <span className="shrink-0">{emoji}</span>
                      <span
                        className="w-2 h-2 rounded-full shrink-0"
                        style={{ backgroundColor: color }}
                      />
                      <span className="truncate">{category}</span>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {/* Regions */}
          <div>
            <p className="text-sm font-medium text-muted-foreground mb-3">Filter by Region</p>
            <div className="grid grid-cols-2 gap-2">
              {/* All button */}
              <button
                onClick={selectAllRegions}
                className={cn(
                  'px-3 py-2 rounded-md text-sm font-medium transition-all text-left',
                  'border',
                  selectedRegions.length === 0
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-transparent text-sidebar-foreground border-border hover:bg-sidebar-accent'
                )}
              >
                All
              </button>
              
              {isLoading ? (
                Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))
              ) : (
                regions.map((region) => {
                  const isSelected = selectedRegions.includes(region);
                  
                  return (
                    <button
                      key={region}
                      onClick={() => toggleRegion(region)}
                      className={cn(
                        'px-3 py-2 rounded-md text-sm font-medium transition-all text-left',
                        'border',
                        isSelected
                          ? 'bg-sidebar-accent border-primary'
                          : 'bg-transparent text-sidebar-foreground border-border hover:bg-sidebar-accent'
                      )}
                    >
                      {region}
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </ScrollArea>

      {/* Reset Filters */}
      <div className="p-4 border-t border-sidebar-border">
        <Button
          variant="outline"
          className="w-full"
          onClick={clearAllFilters}
          disabled={!hasActiveFilters}
        >
          Reset Filters
        </Button>
      </div>
    </div>
  );
}
