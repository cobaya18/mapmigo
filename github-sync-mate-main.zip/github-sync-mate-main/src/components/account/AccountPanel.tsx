import { X, User, Mail, LogOut, Bookmark, Loader2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useAuth } from '@/contexts/AuthContext';
import { useSavedLists } from '@/hooks/useSavedLists';
import { useSavedPlaces } from '@/hooks/useSavedPlaces';

interface AccountPanelProps {
  open: boolean;
  onClose: () => void;
}

export function AccountPanel({ open, onClose }: AccountPanelProps) {
  const { user, signOut, loading } = useAuth();
  const navigate = useNavigate();
  const { data: lists = [] } = useSavedLists();
  const { data: allSavedPlaces = [] } = useSavedPlaces();

  const handleSignOut = async () => {
    await signOut();
    onClose();
    navigate('/');
  };

  const handleSignIn = () => {
    onClose();
    navigate('/auth');
  };

  const totalSavedPlaces = allSavedPlaces.length;
  const collectionsCount = lists.filter(l => l.type === 'collection').length;

  return (
    <>
      {/* Backdrop */}
      {open && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Panel */}
      <div className={`
        fixed top-14 right-0 bottom-0 w-96 max-w-full bg-background border-l border-border z-50
        transform transition-transform duration-300 ease-in-out
        ${open ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="font-semibold text-lg">Account</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <ScrollArea className="h-[calc(100vh-8rem)]">
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : !user ? (
            <div className="p-4 text-center text-muted-foreground">
              <User className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="mb-4">Sign in to view your account</p>
              <Button onClick={handleSignIn}>
                Sign In
              </Button>
            </div>
          ) : (
            <div className="p-4 space-y-6">
              {/* Profile */}
              <div className="flex items-center gap-4">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <User className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Your Profile</h3>
                  <p className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                    <Mail className="h-4 w-4" />
                    {user.email}
                  </p>
                </div>
              </div>

              <Separator />

              {/* Saved Stats */}
              <div>
                <h3 className="font-medium mb-3">Your Saved Places</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-lg bg-muted text-center">
                    <Bookmark className="h-6 w-6 mx-auto mb-2 text-primary" />
                    <p className="text-2xl font-bold">{totalSavedPlaces}</p>
                    <p className="text-sm text-muted-foreground">Saved Places</p>
                  </div>
                  <div className="p-4 rounded-lg bg-muted text-center">
                    <div className="text-2xl mb-2">📁</div>
                    <p className="text-2xl font-bold">{collectionsCount}</p>
                    <p className="text-sm text-muted-foreground">Collections</p>
                  </div>
                </div>
              </div>

              <Separator />

              {/* Actions */}
              <div className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start gap-3 h-12"
                  onClick={handleSignOut}
                >
                  <LogOut className="h-5 w-5" />
                  Sign Out
                </Button>
              </div>

              {/* Footer links */}
              <div className="pt-4 flex items-center justify-center gap-4 text-sm text-muted-foreground">
                <Link 
                  to="/privacy" 
                  className="hover:text-foreground transition-colors"
                  onClick={onClose}
                >
                  Privacy Policy
                </Link>
                <span>•</span>
                <Link 
                  to="/terms" 
                  className="hover:text-foreground transition-colors"
                  onClick={onClose}
                >
                  Terms of Service
                </Link>
              </div>
            </div>
          )}
        </ScrollArea>
      </div>
    </>
  );
}
