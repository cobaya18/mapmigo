import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Search, Bookmark, List, X, MapPin, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { SearchOverlay } from '@/components/search/SearchOverlay';
import type { Location } from '@/types/location';

interface HeaderProps {
  onMenuToggle: () => void;
  onViewToggle: () => void;
  onSavedToggle: () => void;
  onAccountToggle: () => void;
  isListView: boolean;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  locations?: Location[];
  onLocationSelect?: (location: Location) => void;
}

export function Header({ 
  onMenuToggle, 
  onViewToggle,
  onSavedToggle,
  onAccountToggle,
  isListView,
  searchQuery,
  onSearchChange,
  locations = [],
  onLocationSelect,
}: HeaderProps) {
  const [searchFocused, setSearchFocused] = useState(false);

  const handleLocationSelect = (location: Location) => {
    onLocationSelect?.(location);
    onSearchChange('');
    setSearchFocused(false);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 h-14 bg-background border-b border-border">
      <div className="flex items-center justify-between h-full px-3 gap-3">
        {/* Left - Logo + Menu + Search */}
        <div className="flex items-center gap-2 flex-1">
          {/* MapMigo Logo */}
          <Link 
            to="/" 
            className="flex items-center gap-1.5 px-2 py-1 rounded-lg hover:bg-muted transition-colors shrink-0"
          >
            <MapPin className="h-5 w-5 text-primary" />
            <span className="font-semibold text-foreground hidden sm:inline">MapMigo</span>
          </Link>

          <Button
            variant="ghost"
            size="icon"
            onClick={onMenuToggle}
            className="shrink-0"
          >
            <Menu className="h-5 w-5" />
          </Button>
          
          {/* Search Bar */}
          <div className="relative flex-1 max-w-md">
            <Input
              placeholder="Search places..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              onFocus={() => setSearchFocused(true)}
              className="pr-16 bg-muted/50 border-border"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-10 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            )}
            <button className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-primary text-primary-foreground rounded">
              <Search className="h-4 w-4" />
            </button>

            {/* Search Overlay */}
            <SearchOverlay
              isOpen={searchFocused && searchQuery.length > 0}
              onClose={() => setSearchFocused(false)}
              searchQuery={searchQuery}
              locations={locations}
              onSelectLocation={handleLocationSelect}
            />
          </div>
        </div>

        {/* Right - Account + Saved + List View */}
        <div className="flex items-center gap-2 shrink-0">
          <Button variant="outline" size="sm" className="gap-1.5" onClick={onSavedToggle}>
            <Bookmark className="h-4 w-4" />
            <span className="hidden sm:inline">Saved</span>
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={onViewToggle}
            className="gap-1.5"
          >
            <List className="h-4 w-4" />
            <span className="hidden sm:inline">List View</span>
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-9 w-9"
            onClick={onAccountToggle}
          >
            <User className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  );
}
