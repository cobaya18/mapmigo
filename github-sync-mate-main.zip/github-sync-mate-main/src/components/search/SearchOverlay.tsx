import { useEffect, useRef } from 'react';
import { MapPin } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { getCategoryColor, getCategoryEmoji } from '@/lib/categoryConfig';
import type { Location } from '@/types/location';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  searchQuery: string;
  locations: Location[];
  onSelectLocation: (location: Location) => void;
}

export function SearchOverlay({
  isOpen,
  onClose,
  searchQuery,
  locations,
  onSelectLocation,
}: SearchOverlayProps) {
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (overlayRef.current && !overlayRef.current.contains(e.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  if (!isOpen || !searchQuery.trim()) return null;

  const filtered = locations.slice(0, 8); // Show max 8 results

  return (
    <div 
      ref={overlayRef}
      className="absolute top-full left-0 right-0 mt-1 bg-popover border border-border rounded-lg shadow-xl z-50 overflow-hidden"
    >
      {filtered.length === 0 ? (
        <div className="p-4 text-center text-muted-foreground">
          <MapPin className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p>No places found for "{searchQuery}"</p>
        </div>
      ) : (
        <ScrollArea className="max-h-80">
          <div className="p-2">
            <p className="text-xs text-muted-foreground px-2 py-1 mb-1">
              {locations.length} result{locations.length !== 1 ? 's' : ''}
            </p>
            {filtered.map((location) => (
              <button
                key={location.id}
                onClick={() => {
                  onSelectLocation(location);
                  onClose();
                }}
                className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-muted transition-colors text-left"
              >
                {/* Thumbnail or emoji */}
                {location.image_url ? (
                  <div className="w-10 h-10 rounded-lg overflow-hidden bg-muted shrink-0">
                    <img 
                      src={location.image_url} 
                      alt="" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                ) : (
                  <div 
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-lg shrink-0"
                    style={{ backgroundColor: `${getCategoryColor(location.category)}20` }}
                  >
                    {getCategoryEmoji(location.category)}
                  </div>
                )}
                
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{location.title}</p>
                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span 
                      className="w-2 h-2 rounded-full shrink-0" 
                      style={{ backgroundColor: getCategoryColor(location.category) }}
                    />
                    <span className="truncate">
                      {location.category}
                      {location.region && ` • ${location.region}`}
                    </span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
