import { memo, useCallback, useMemo } from 'react';
import { X, MapPin, ExternalLink, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { getCategoryColor, getCategoryEmoji } from '@/lib/categoryConfig';
import { useAllUserSavedPlaces, useSavePlace } from '@/hooks/useSavedPlaces';
import { useSavedLists } from '@/hooks/useSavedLists';
import { useAuth } from '@/contexts/AuthContext';
import type { Location } from '@/types/location';

interface PlacesListPanelProps {
  open: boolean;
  onClose: () => void;
  locations: Location[];
  onPlaceClick: (location: Location) => void;
}

export function PlacesListPanel({ open, onClose, locations, onPlaceClick }: PlacesListPanelProps) {
  const { user } = useAuth();
  const { data: savedPlaces = [] } = useAllUserSavedPlaces();
  const { data: lists = [] } = useSavedLists();
  const savePlace = useSavePlace();

  // Create a Set for O(1) lookup instead of O(n) array.some()
  const savedPlaceIds = useMemo(() => 
    new Set(savedPlaces.map(sp => sp.place_id)), 
    [savedPlaces]
  );

  const isPlaceSaved = useCallback((placeId: string) => {
    return savedPlaceIds.has(placeId);
  }, [savedPlaceIds]);

  const handleQuickSave = async (e: React.MouseEvent, placeId: string) => {
    e.stopPropagation();
    if (!user) {
      window.location.href = '/auth';
      return;
    }
    const wantToGoList = lists.find(l => l.type === 'want_to_go');
    if (wantToGoList && !isPlaceSaved(placeId)) {
      await savePlace.mutateAsync({ placeId, listId: wantToGoList.id });
    }
  };

  return (
    <>
      {/* Backdrop */}
      {open && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Panel */}
      <div className={`
        fixed top-14 right-0 bottom-0 w-[420px] max-w-full bg-background border-l border-border z-50
        transform transition-transform duration-300 ease-in-out
        ${open ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="flex items-center justify-between p-4 border-b border-border">
          <div>
            <h2 className="font-semibold text-lg">Places</h2>
            <p className="text-sm text-muted-foreground">{locations.length} results</p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <ScrollArea className="h-[calc(100vh-8rem)]">
          <div className="p-3 space-y-3">
            {locations.map((location) => {
              const saved = isPlaceSaved(location.id);
              
              return (
                <div
                  key={location.id}
                  className="group flex gap-3 p-3 rounded-xl border border-border bg-card hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => {
                    onPlaceClick(location);
                    onClose();
                  }}
                >
                  {/* Thumbnail */}
                  <div className="w-24 h-20 rounded-lg overflow-hidden bg-muted shrink-0">
                    {location.image_url ? (
                      <img 
                        src={location.image_url} 
                        alt={location.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div 
                        className="w-full h-full flex items-center justify-center text-2xl"
                        style={{ backgroundColor: `${getCategoryColor(location.category)}20` }}
                      >
                        {getCategoryEmoji(location.category)}
                      </div>
                    )}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0 py-0.5">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-medium text-sm leading-tight line-clamp-2">
                        {location.title}
                      </h4>
                      <button
                        onClick={(e) => handleQuickSave(e, location.id)}
                        className={`shrink-0 p-1 rounded transition-colors ${
                          saved 
                            ? 'text-primary' 
                            : 'text-muted-foreground hover:text-primary'
                        }`}
                      >
                        <Bookmark className={`h-4 w-4 ${saved ? 'fill-current' : ''}`} />
                      </button>
                    </div>
                    
                    <div className="flex items-center gap-1.5 mt-1">
                      <span 
                        className="w-2 h-2 rounded-full shrink-0" 
                        style={{ backgroundColor: getCategoryColor(location.category) }}
                      />
                      <span className="text-xs text-muted-foreground truncate">
                        {location.category}
                        {location.type && ` • ${location.type}`}
                        {location.municipality && ` • ${location.municipality}`}
                        {location.region && ` • ${location.region}`}
                      </span>
                    </div>
                    
                    {location.description && (
                      <p className="text-xs text-muted-foreground mt-1.5 line-clamp-2 leading-relaxed">
                        {location.description}
                      </p>
                    )}

                    {/* Quick actions */}
                    <div className="flex items-center gap-2 mt-2">
                      {location.google_maps_url && (
                        <a
                          href={location.google_maps_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                        >
                          <ExternalLink className="h-3 w-3" />
                          Directions
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}

            {locations.length === 0 && (
              <div className="text-center py-12 text-muted-foreground">
                <MapPin className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No places match your filters</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </>
  );
}
