import { useState, useEffect } from 'react';
import { Check, Plus, Loader2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useSavedLists } from '@/hooks/useSavedLists';
import { useAllUserSavedPlaces, useSavePlace, useRemoveSavedPlace } from '@/hooks/useSavedPlaces';
import { useAuth } from '@/contexts/AuthContext';
import { LoginPromptModal } from '@/components/auth/LoginPromptModal';
import { CreateCollectionModal } from './CreateCollectionModal';
import { Bookmark } from 'lucide-react';

interface SaveDropdownProps {
  placeId: string;
  trigger?: React.ReactNode;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export function SaveDropdown({ placeId, trigger, open: controlledOpen, onOpenChange }: SaveDropdownProps) {
  const { user } = useAuth();
  const { data: lists = [], isLoading: listsLoading } = useSavedLists();
  const { data: savedPlaces = [] } = useAllUserSavedPlaces();
  const savePlace = useSavePlace();
  const removePlace = useRemoveSavedPlace();
  
  const [showLoginPrompt, setShowLoginPrompt] = useState(false);
  const [showCreateCollection, setShowCreateCollection] = useState(false);
  const [internalOpen, setInternalOpen] = useState(false);

  // Use controlled or uncontrolled open state
  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : internalOpen;

  const handleOpenChange = (newOpen: boolean) => {
    if (newOpen && !user) {
      setShowLoginPrompt(true);
      return;
    }
    if (isControlled) {
      onOpenChange?.(newOpen);
    } else {
      setInternalOpen(newOpen);
    }
  };

  const isPlaceInList = (listId: string) => {
    return savedPlaces.some(sp => sp.place_id === placeId && sp.list_id === listId);
  };

  const isSavedAnywhere = savedPlaces.some(sp => sp.place_id === placeId);

  const handleToggleList = async (listId: string) => {
    if (isPlaceInList(listId)) {
      await removePlace.mutateAsync({ placeId, listId });
    } else {
      await savePlace.mutateAsync({ placeId, listId });
    }
  };

  const wantToGoList = lists.find(l => l.type === 'want_to_go');
  const beenThereList = lists.find(l => l.type === 'been_there');
  const collections = lists.filter(l => l.type === 'collection');

  return (
    <>
      <DropdownMenu open={open} onOpenChange={handleOpenChange}>
        <DropdownMenuTrigger asChild>
          {trigger || (
            <Button 
              variant={isSavedAnywhere ? "default" : "outline"} 
              size="sm"
              className="gap-1.5"
            >
              <Bookmark className={`h-4 w-4 ${isSavedAnywhere ? 'fill-current' : ''}`} />
              {isSavedAnywhere ? 'Saved' : 'Save'}
            </Button>
          )}
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {listsLoading ? (
            <div className="flex items-center justify-center p-4">
              <Loader2 className="h-4 w-4 animate-spin" />
            </div>
          ) : (
            <>
              {wantToGoList && (
                <DropdownMenuItem 
                  onClick={() => handleToggleList(wantToGoList.id)}
                  className="cursor-pointer"
                >
                  <span className="mr-2">{wantToGoList.icon}</span>
                  {wantToGoList.name}
                  {isPlaceInList(wantToGoList.id) && (
                    <Check className="ml-auto h-4 w-4" />
                  )}
                </DropdownMenuItem>
              )}
              {beenThereList && (
                <DropdownMenuItem 
                  onClick={() => handleToggleList(beenThereList.id)}
                  className="cursor-pointer"
                >
                  <span className="mr-2">{beenThereList.icon}</span>
                  {beenThereList.name}
                  {isPlaceInList(beenThereList.id) && (
                    <Check className="ml-auto h-4 w-4" />
                  )}
                </DropdownMenuItem>
              )}
              
              {collections.length > 0 && (
                <>
                  <DropdownMenuSeparator />
                  {collections.map((collection) => (
                    <DropdownMenuItem 
                      key={collection.id}
                      onClick={() => handleToggleList(collection.id)}
                      className="cursor-pointer"
                    >
                      <span className="mr-2">{collection.icon}</span>
                      {collection.name}
                      {isPlaceInList(collection.id) && (
                        <Check className="ml-auto h-4 w-4" />
                      )}
                    </DropdownMenuItem>
                  ))}
                </>
              )}
              
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={() => {
                  handleOpenChange(false);
                  setShowCreateCollection(true);
                }}
                className="cursor-pointer"
              >
                <Plus className="mr-2 h-4 w-4" />
                Create new collection
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>

      <LoginPromptModal 
        open={showLoginPrompt} 
        onOpenChange={setShowLoginPrompt} 
      />
      <CreateCollectionModal 
        open={showCreateCollection} 
        onOpenChange={setShowCreateCollection} 
      />
    </>
  );
}
