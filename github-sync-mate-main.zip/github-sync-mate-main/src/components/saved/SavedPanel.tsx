import { useState } from 'react';
import { X, Trash2, Plus, ChevronRight, Loader2, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useSavedLists, useDeleteList } from '@/hooks/useSavedLists';
import { useSavedPlaces, useRemoveSavedPlace } from '@/hooks/useSavedPlaces';
import { useAuth } from '@/contexts/AuthContext';
import { CreateCollectionModal } from './CreateCollectionModal';
import { toast } from '@/hooks/use-toast';
import { getCategoryColor } from '@/lib/categoryConfig';
import type { Location } from '@/types/location';

interface SavedPanelProps {
  open: boolean;
  onClose: () => void;
  onPlaceClick: (location: Location) => void;
}

export function SavedPanel({ open, onClose, onPlaceClick }: SavedPanelProps) {
  const { user, signOut } = useAuth();
  const { data: lists = [], isLoading: listsLoading } = useSavedLists();
  const [expandedList, setExpandedList] = useState<string | null>(null);
  const [showCreateCollection, setShowCreateCollection] = useState(false);

  const wantToGoList = lists.find(l => l.type === 'want_to_go');
  const beenThereList = lists.find(l => l.type === 'been_there');
  const collections = lists.filter(l => l.type === 'collection');

  return (
    <>
      {open && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}
      <div className={`
        fixed top-14 right-0 bottom-0 w-96 bg-background border-l border-border z-50
        transform transition-transform duration-300 ease-in-out
        ${open ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="font-semibold text-lg">Saved Places</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        <ScrollArea className="h-[calc(100vh-8rem)]">
          {!user ? (
            <div className="p-4 text-center text-muted-foreground">
              <Bookmark className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="mb-4">Sign in to save your favorite places</p>
              <Button onClick={() => window.location.href = '/auth'}>
                Sign In
              </Button>
            </div>
          ) : listsLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <div className="p-2">
              {/* Want to Go */}
              {wantToGoList && (
                <ListSection
                  list={wantToGoList}
                  isExpanded={expandedList === wantToGoList.id}
                  onToggle={() => setExpandedList(
                    expandedList === wantToGoList.id ? null : wantToGoList.id
                  )}
                  onPlaceClick={onPlaceClick}
                  onClose={onClose}
                />
              )}

              {/* Been There */}
              {beenThereList && (
                <ListSection
                  list={beenThereList}
                  isExpanded={expandedList === beenThereList.id}
                  onToggle={() => setExpandedList(
                    expandedList === beenThereList.id ? null : beenThereList.id
                  )}
                  onPlaceClick={onPlaceClick}
                  onClose={onClose}
                />
              )}

              <Separator className="my-2" />

              {/* My Collections header */}
              <div className="flex items-center justify-between px-2 py-2">
                <span className="text-sm font-medium text-muted-foreground">My Collections</span>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => setShowCreateCollection(true)}
                  className="h-7 px-2"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              {/* Custom Collections */}
              {collections.map(collection => (
                <ListSection
                  key={collection.id}
                  list={collection}
                  isExpanded={expandedList === collection.id}
                  onToggle={() => setExpandedList(
                    expandedList === collection.id ? null : collection.id
                  )}
                  onPlaceClick={onPlaceClick}
                  onClose={onClose}
                  canDelete
                />
              ))}

              {collections.length === 0 && (
                <p className="text-sm text-muted-foreground px-2 py-4 text-center">
                  No collections yet
                </p>
              )}

            </div>
          )}
        </ScrollArea>
      </div>

      <CreateCollectionModal 
        open={showCreateCollection} 
        onOpenChange={setShowCreateCollection} 
      />
    </>
  );
}

interface ListSectionProps {
  list: { id: string; name: string; icon: string | null; type: string };
  isExpanded: boolean;
  onToggle: () => void;
  onPlaceClick: (location: Location) => void;
  onClose: () => void;
  canDelete?: boolean;
}

function ListSection({ list, isExpanded, onToggle, onPlaceClick, onClose, canDelete }: ListSectionProps) {
  const { data: savedPlaces = [], isLoading } = useSavedPlaces(isExpanded ? list.id : undefined);
  const removePlace = useRemoveSavedPlace();
  const deleteList = useDeleteList();

  const handleDeleteList = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await deleteList.mutateAsync(list.id);
      toast({ title: 'Collection deleted' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to delete collection', variant: 'destructive' });
    }
  };

  const handleRemovePlace = async (e: React.MouseEvent, placeId: string) => {
    e.stopPropagation();
    try {
      await removePlace.mutateAsync({ placeId, listId: list.id });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to remove place', variant: 'destructive' });
    }
  };

  return (
    <div className="mb-1">
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-2 px-2 py-2 rounded-lg hover:bg-muted transition-colors"
      >
        <ChevronRight className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
        <span className="text-lg">{list.icon}</span>
        <span className="flex-1 text-left font-medium">{list.name}</span>
        {canDelete && (
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 opacity-0 group-hover:opacity-100"
            onClick={handleDeleteList}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        )}
      </button>
      
      {isExpanded && (
        <div className="mt-1 space-y-2 px-2">
          {isLoading ? (
            <div className="flex items-center justify-center py-4">
              <Loader2 className="h-4 w-4 animate-spin" />
            </div>
          ) : savedPlaces.length === 0 ? (
            <p className="text-sm text-muted-foreground py-2 px-2">No places saved</p>
          ) : (
            savedPlaces.map((sp) => {
              const place = sp.place as Location;
              if (!place) return null;
              
              const categoryColor = getCategoryColor(place.category);
              
              return (
                <div
                  key={sp.id}
                  className="group flex gap-3 p-2 rounded-xl border border-border bg-card hover:bg-muted/50 cursor-pointer transition-colors"
                  onClick={() => {
                    onPlaceClick(place);
                    onClose();
                  }}
                >
                  {/* Thumbnail */}
                  <div className="w-20 h-16 rounded-lg overflow-hidden bg-muted shrink-0">
                    {place.image_url ? (
                      <img 
                        src={place.image_url} 
                        alt={place.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        <Bookmark className="h-6 w-6" />
                      </div>
                    )}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0 py-0.5">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-medium text-sm leading-tight line-clamp-1">
                        {place.title}
                      </h4>
                      <button
                        onClick={(e) => handleRemovePlace(e, sp.place_id)}
                        className="text-muted-foreground hover:text-primary shrink-0 p-0.5"
                      >
                        <Bookmark className="h-4 w-4 fill-current" />
                      </button>
                    </div>
                    
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span 
                        className="w-2 h-2 rounded-full shrink-0" 
                        style={{ backgroundColor: categoryColor }}
                      />
                      <span className="text-xs text-muted-foreground truncate">
                        {place.category}
                        {place.type && ` • ${place.type}`}
                        {place.municipality && ` • ${place.municipality}`}
                        {place.region && ` • ${place.region}`}
                      </span>
                    </div>
                    
                    {place.description && (
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2 leading-relaxed">
                        {place.description}
                      </p>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
