import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCreateList } from '@/hooks/useSavedLists';
import { toast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

interface CreateCollectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const EMOJI_OPTIONS = ['📁', '❤️', '⭐', '🏖️', '🍴', '🎯', '🏃', '📷', '🎵', '🌿'];

export function CreateCollectionModal({ open, onOpenChange }: CreateCollectionModalProps) {
  const [name, setName] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('📁');
  const createList = useCreateList();

  const handleCreate = async () => {
    if (!name.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter a collection name',
        variant: 'destructive',
      });
      return;
    }

    try {
      await createList.mutateAsync({ name: name.trim(), icon: selectedEmoji });
      toast({
        title: 'Collection created',
        description: `"${name}" has been created`,
      });
      setName('');
      setSelectedEmoji('📁');
      onOpenChange(false);
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create collection',
        variant: 'destructive',
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Create new collection</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="collection-name">Name</Label>
            <Input
              id="collection-name"
              placeholder="My favorite spots..."
              value={name}
              onChange={(e) => setName(e.target.value)}
              disabled={createList.isPending}
            />
          </div>
          <div className="space-y-2">
            <Label>Icon</Label>
            <div className="flex flex-wrap gap-2">
              {EMOJI_OPTIONS.map((emoji) => (
                <button
                  key={emoji}
                  type="button"
                  onClick={() => setSelectedEmoji(emoji)}
                  className={`h-10 w-10 rounded-lg text-lg flex items-center justify-center transition-colors ${
                    selectedEmoji === emoji
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted hover:bg-muted/80'
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
          <Button 
            onClick={handleCreate} 
            className="w-full"
            disabled={createList.isPending}
          >
            {createList.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            Create Collection
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
