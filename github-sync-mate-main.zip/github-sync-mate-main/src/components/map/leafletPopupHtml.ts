import type { Location } from "@/types/location";

// Category color mapping
const CATEGORY_COLORS: Record<string, string> = {
  'Beach': '#0ea5e9',
  'Food': '#f59e0b',
  'Hike/Nature': '#22c55e',
  'History': '#a855f7',
  'Museum': '#8b5cf6',
  'Park': '#10b981',
  'River/Waterfall': '#06b6d4',
  'Viewpoint': '#ec4899',
  'Entertainment': '#ef4444',
  'Nightlife': '#ec4899',
  'Shopping': '#f59e0b',
  'Tour/Activity': '#3b82f6',
  'Interest Point': '#eab308',
};

function getCategoryColor(category: string): string {
  return CATEGORY_COLORS[category] || '#6b7280';
}

export function buildPlacePopupHtml(location: Location, isSaved: boolean = false) {
  const title = escapeHtml(location.title);
  const category = escapeHtml(location.category || "");
  const region = escapeHtml(location.region || "");
  const categoryColor = getCategoryColor(location.category);
  const description = location.description ? escapeHtml(location.description) : "";

  const image = location.image_url
    ? `<div class="mm-popup__image">
        <img src="${escapeAttr(location.image_url)}" alt="${title}" loading="lazy" />
        ${location.image_credit ? `<div class="mm-popup__image-credit">${escapeHtml(location.image_credit)}</div>` : ""}
      </div>`
    : "";

  // Build details section
  const details = [];
  
  if (location.website_url) {
    details.push(`
      <div class="mm-popup__detail">
        <span class="mm-popup__detail-label">Website:</span>
        <a class="mm-popup__detail-link" href="${escapeAttr(location.website_url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(location.website_url)}</a>
      </div>
    `);
  }
  
  if (location.cost) {
    details.push(`
      <div class="mm-popup__detail">
        <span class="mm-popup__detail-label">Cost:</span>
        <span>${escapeHtml(location.cost)}</span>
      </div>
    `);
  }
  
  if (location.parking) {
    details.push(`
      <div class="mm-popup__detail">
        <span class="mm-popup__detail-label">Parking:</span>
        <span>${escapeHtml(location.parking)}</span>
      </div>
    `);
  }
  

  if (location.access) {
    details.push(`
      <div class="mm-popup__detail">
        <span class="mm-popup__detail-label">Access:</span>
        <span>${escapeHtml(location.access)}</span>
      </div>
    `);
  }

  const googleMapsLink = location.google_maps_url
    ? `<a class="mm-popup__gmaps" href="${escapeAttr(location.google_maps_url)}" target="_blank" rel="noopener noreferrer">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
        Open in Google Maps
      </a>`
    : "";

  const saveButtonClass = isSaved ? 'mm-popup__save mm-popup__save--saved' : 'mm-popup__save';
  const saveButtonText = isSaved ? 'Saved' : 'Save';
  const saveIconFill = isSaved ? 'currentColor' : 'none';

  return `
    <div class="mm-popup">
      <div class="mm-popup__header">
        <div class="mm-popup__title-row">
          <h3 class="mm-popup__title">${title}</h3>
        </div>
        <div class="mm-popup__subtitle">
          <span class="mm-popup__category-dot" style="background-color: ${categoryColor}"></span>
          ${category}${location.type ? ` • ${escapeHtml(location.type)}` : ""}${location.municipality ? ` • ${escapeHtml(location.municipality)}` : ""}${region ? ` • ${region}` : ""}
        </div>
      </div>
      ${image}
      ${description ? `<p class="mm-popup__desc">${description}</p>` : ""}
      ${details.length > 0 ? `<div class="mm-popup__details">${details.join("")}</div>` : ""}
      <div class="mm-popup__actions">
        <button class="${saveButtonClass}" data-place-id="${escapeAttr(location.id)}" title="Save place">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="${saveIconFill}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
          ${saveButtonText}
        </button>
        ${googleMapsLink}
      </div>
    </div>
  `;
}

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function escapeAttr(value: string) {
  return escapeHtml(value).replace(/`/g, "&#096;");
}
