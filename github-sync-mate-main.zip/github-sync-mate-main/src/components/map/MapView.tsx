import { useEffect, useRef, useState, useCallback } from "react";
import L from "leaflet";
import type { Location } from "@/types/location";
import { buildPlacePopupHtml } from "./leafletPopupHtml";
import { SaveDropdown } from "@/components/saved/SaveDropdown";
import { useAllUserSavedPlaces } from "@/hooks/useSavedPlaces";
import { Button } from "@/components/ui/button";
import { Bookmark } from "lucide-react";
import { getCategoryColor, getCategoryEmoji } from "@/lib/categoryConfig";

interface MapViewProps {
  locations: Location[];
  selectedLocation: Location | null;
  onLocationSelect: (location: Location | null) => void;
  sidebarOpen?: boolean;
  rightOverlayWidth?: number;
  topOverlayHeight?: number;
}

// Puerto Rico center coordinates
const PUERTO_RICO_CENTER: [number, number] = [18.2208, -66.5901];
const DEFAULT_ZOOM = 9;

const createCustomIcon = (category: string, isSelected: boolean) => {
  const color = getCategoryColor(category);
  const emoji = getCategoryEmoji(category);
  const size = isSelected ? 44 : 36;

  return L.divIcon({
    className: "mm-marker",
    html: `
      <div
        class="mm-marker__dot ${isSelected ? "mm-marker__dot--active" : ""}"
        style="background-color:${color};width:${size}px;height:${size}px;"
      >
        <span style="font-size:${isSelected ? 20 : 16}px;line-height:1;">${emoji}</span>
      </div>
    `,
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2],
  });
};

export function MapView({ locations, selectedLocation, onLocationSelect, sidebarOpen, rightOverlayWidth = 0, topOverlayHeight = 56 }: MapViewProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const layerRef = useRef<L.LayerGroup | null>(null);
  const markersRef = useRef<Map<string, L.Marker>>(new Map());
  
  const [saveDropdownPlaceId, setSaveDropdownPlaceId] = useState<string | null>(null);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const { data: savedPlaces = [] } = useAllUserSavedPlaces();

  const isPlaceSaved = useCallback((placeId: string) => {
    return savedPlaces.some(sp => sp.place_id === placeId);
  }, [savedPlaces]);

  // Init map once
  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const container = containerRef.current;
    
    // Create the map
    const map = L.map(container, {
      center: PUERTO_RICO_CENTER,
      zoom: DEFAULT_ZOOM,
      zoomControl: false,
    });

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution:
        '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);

    const layer = L.layerGroup().addTo(map);

    mapRef.current = map;
    layerRef.current = layer;

    // Force invalidateSize after mount
    requestAnimationFrame(() => {
      map.invalidateSize();
    });

    // Also on window resize
    const onResize = () => map.invalidateSize();
    window.addEventListener("resize", onResize);

    return () => {
      window.removeEventListener("resize", onResize);
      markersRef.current.clear();
      map.remove();
      mapRef.current = null;
      layerRef.current = null;
    };
  }, []);

  // Handle save button clicks from popup and ensure external links work
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      
      // Handle Google Maps and external links - ensure they open correctly
      const link = target.closest('a.mm-popup__gmaps, a.mm-popup__detail-link') as HTMLAnchorElement;
      if (link) {
        e.stopPropagation();
        // Let the default behavior happen for links
        return;
      }
      
      // Handle save button clicks
      const saveButton = target.closest('.mm-popup__save') as HTMLElement;
      if (saveButton) {
        e.preventDefault();
        e.stopPropagation();
        const placeId = saveButton.dataset.placeId;
        if (placeId) {
          setSaveDropdownPlaceId(placeId);
          setDropdownOpen(true);
        }
      }
    };

    document.addEventListener('click', handleClick);
    return () => document.removeEventListener('click', handleClick);
  }, []);

  // Render markers
  useEffect(() => {
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();
    markersRef.current.clear();

    for (const location of locations) {
      const marker = L.marker([location.latitude, location.longitude], {
        icon: createCustomIcon(location.category, selectedLocation?.id === location.id),
        keyboard: false,
      });

      marker.on("click", () => onLocationSelect(location));

      // Ensure the popup is always fully visible.
      // Leaflet's auto-pan will move the map so the popup stays on-screen.
      // We add padding to account for our fixed header + left sidebar + right panels.
      marker.bindPopup(buildPlacePopupHtml(location, isPlaceSaved(location.id)), {
        closeButton: true,
        maxWidth: 300,
        className: "mm-leaflet-popup",
        autoPan: true,
        keepInView: true,
        autoPanPaddingTopLeft: L.point(
          (sidebarOpen ? 384 : 0) + 16,
          (topOverlayHeight ?? 56) + 16
        ),
        autoPanPaddingBottomRight: L.point((rightOverlayWidth ?? 0) + 16, 16),
      });

      marker.addTo(layer);
      markersRef.current.set(location.id, marker);
    }
  }, [locations, onLocationSelect, selectedLocation?.id, isPlaceSaved, sidebarOpen, rightOverlayWidth, topOverlayHeight]);

  // Update popup content when saved state changes
  useEffect(() => {
    if (!selectedLocation) return;
    const marker = markersRef.current.get(selectedLocation.id);
    if (marker) {
      marker.setPopupContent(buildPlacePopupHtml(selectedLocation, isPlaceSaved(selectedLocation.id)));
    }
  }, [savedPlaces, selectedLocation, isPlaceSaved]);

  // Open popup for selected marker (Leaflet auto-pan handles keeping popup fully visible)
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    if (selectedLocation) {
      const marker = markersRef.current.get(selectedLocation.id);
      marker?.openPopup();
    }
  }, [selectedLocation]);

  // Invalidate map size when sidebar toggles
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    // Small delay to let the CSS transition complete
    const timeout = setTimeout(() => {
      map.invalidateSize();
    }, 350);

    return () => clearTimeout(timeout);
  }, [sidebarOpen]);

  const handleDropdownOpenChange = (open: boolean) => {
    setDropdownOpen(open);
    if (!open) {
      setSaveDropdownPlaceId(null);
    }
  };

  return (
    <>
      <div 
        ref={containerRef} 
        style={{ 
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
        }} 
      />
      
      {/* SaveDropdown rendered at a fixed position when triggered */}
      {saveDropdownPlaceId && (
        <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[1000]">
          <SaveDropdown 
            placeId={saveDropdownPlaceId}
            open={dropdownOpen}
            onOpenChange={handleDropdownOpenChange}
            trigger={
              <Button 
                variant="outline" 
                size="sm"
                className="gap-1.5"
              >
                <Bookmark className="h-4 w-4" />
                Save to...
              </Button>
            }
          />
        </div>
      )}

      {/* Overlay to close dropdown */}
      {saveDropdownPlaceId && !dropdownOpen && (
        <div 
          className="fixed inset-0 z-[999]" 
          onClick={() => setSaveDropdownPlaceId(null)}
        />
      )}
    </>
  );
}
