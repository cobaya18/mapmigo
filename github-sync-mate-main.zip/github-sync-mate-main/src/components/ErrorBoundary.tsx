import * as React from "react";

type Props = {
  children: React.ReactNode;
};

type State = {
  error: Error | null;
  info: React.ErrorInfo | null;
};

export class ErrorBoundary extends React.Component<Props, State> {
  state: State = { error: null, info: null };

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Keep this minimal; helps identify the component stack.
    // eslint-disable-next-line no-console
    console.error("ErrorBoundary caught:", error, info);
    this.setState({ error, info });
  }

  render() {
    const { error, info } = this.state;
    if (!error) return this.props.children;

    return (
      <main className="min-h-screen bg-background text-foreground p-6">
        <section className="mx-auto max-w-3xl space-y-4">
          <header>
            <h1 className="text-xl font-semibold">App crashed</h1>
            <p className="text-sm text-muted-foreground">
              This is a temporary debug screen so we can pinpoint which component is breaking the render.
            </p>
          </header>

          <article className="rounded-lg border bg-card p-4">
            <h2 className="text-sm font-medium">Error</h2>
            <pre className="mt-2 whitespace-pre-wrap text-xs text-muted-foreground">{String(error?.stack || error?.message)}</pre>
          </article>

          {info?.componentStack && (
            <article className="rounded-lg border bg-card p-4">
              <h2 className="text-sm font-medium">Component stack</h2>
              <pre className="mt-2 whitespace-pre-wrap text-xs text-muted-foreground">{info.componentStack}</pre>
            </article>
          )}
        </section>
      </main>
    );
  }
}
