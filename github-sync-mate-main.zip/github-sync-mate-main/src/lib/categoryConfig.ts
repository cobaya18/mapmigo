// Unified category configuration for consistent styling across the app

export interface CategoryConfig {
  slug: string;
  category: string;
  icon: string;
  label: string;
  color: string;
}

export const categoryConfig: CategoryConfig[] = [
  { slug: 'beaches', category: 'Beach', icon: '🏖️', label: 'Beaches', color: '#0ea5e9' },
  { slug: 'entertainment', category: 'Entertainment', icon: '🎟️', label: 'Entertainment', color: '#ec4899' },
  { slug: 'food', category: 'Food', icon: '🍽️', label: 'Food', color: '#f59e0b' },
  { slug: 'hikes', category: 'Hike/Nature', icon: '🥾', label: 'Hikes', color: '#22c55e' },
  { slug: 'history', category: 'History', icon: '🏛️', label: 'History', color: '#a855f7' },
  { slug: 'points-of-interest', category: 'Interest Point', icon: '📍', label: 'Points of Interest', color: '#64748b' },
  { slug: 'museums', category: 'Museum', icon: '🖼️', label: 'Museums', color: '#8b5cf6' },
  { slug: 'nightlife', category: 'Nightlife', icon: '🎵', label: 'Nightlife', color: '#8b5cf6' },
  { slug: 'parks', category: 'Park', icon: '🌳', label: 'Parks', color: '#10b981' },
  { slug: 'waterfalls', category: 'River/Waterfall', icon: '💧', label: 'Waterfalls', color: '#06b6d4' },
  { slug: 'shopping', category: 'Shopping', icon: '🛍️', label: 'Shopping', color: '#ec4899' },
  { slug: 'tours', category: 'Tour/Activity', icon: '🧭', label: 'Tours', color: '#f97316' },
  { slug: 'viewpoints', category: 'Viewpoint', icon: '👀', label: 'Viewpoints', color: '#6366f1' },
];

export function getCategoryBySlug(slug: string): string | undefined {
  return categoryConfig.find(c => c.slug === slug)?.category;
}

export function getSlugByCategory(category: string): string | undefined {
  return categoryConfig.find(c => c.category === category)?.slug;
}

export function getCategoryColor(category: string): string {
  return categoryConfig.find(c => c.category === category)?.color || '#6b7280';
}

export function getCategoryEmoji(category: string): string {
  return categoryConfig.find(c => c.category === category)?.icon || '📍';
}

export function getCategoryLabel(category: string): string {
  return categoryConfig.find(c => c.category === category)?.label || category;
}
