import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

const ImportData = () => {
  const [isImporting, setIsImporting] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const handleImport = async () => {
    setIsImporting(true);
    setResult(null);
    
    try {
      // Fetch the CSV file from the public data
      const response = await fetch('/data/places.csv');
      const csvData = await response.text();
      
      // Call the edge function to import
      const { data, error } = await supabase.functions.invoke('import-places', {
        body: { csvData }
      });
      
      if (error) throw error;
      
      setResult(`Success! ${data.count} places imported.`);
      toast.success(`Imported ${data.count} places successfully!`);
    } catch (error) {
      console.error('Import error:', error);
      const message = error instanceof Error ? error.message : 'Unknown error';
      setResult(`Error: ${message}`);
      toast.error('Import failed: ' + message);
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="max-w-md w-full space-y-6 text-center">
        <h1 className="text-2xl font-bold">Import Places Data</h1>
        <p className="text-muted-foreground">
          Click the button below to import all places from the CSV file into the database.
        </p>
        
        <Button 
          onClick={handleImport} 
          disabled={isImporting}
          size="lg"
          className="w-full"
        >
          {isImporting ? 'Importing...' : 'Import Places'}
        </Button>
        
        {result && (
          <p className={result.startsWith('Error') ? 'text-destructive' : 'text-green-600'}>
            {result}
          </p>
        )}
      </div>
    </div>
  );
};

export default ImportData;
