import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center gap-4">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-semibold">Privacy Policy</h1>
        </div>
      </header>
      
      <main className="max-w-3xl mx-auto px-4 py-8 prose prose-neutral dark:prose-invert">
        <p className="text-muted-foreground">Last updated: December 2024</p>
        
        <h2>Information We Collect</h2>
        <p>
          MapMigo collects minimal information necessary to provide our service:
        </p>
        <ul>
          <li><strong>Account Information:</strong> Email address when you create an account</li>
          <li><strong>Saved Places:</strong> Places you choose to save to your lists</li>
          <li><strong>Usage Data:</strong> Basic analytics to improve the service</li>
        </ul>
        
        <h2>How We Use Your Information</h2>
        <p>We use your information to:</p>
        <ul>
          <li>Provide and maintain the MapMigo service</li>
          <li>Allow you to save and organize places</li>
          <li>Improve and optimize our platform</li>
        </ul>
        
        <h2>Data Security</h2>
        <p>
          We implement appropriate security measures to protect your personal information. 
          Your data is stored securely and we do not sell your information to third parties.
        </p>
        
        <h2>Contact Us</h2>
        <p>
          If you have questions about this Privacy Policy, please contact us at privacy@mapmigo.com
        </p>
      </main>
    </div>
  );
}
