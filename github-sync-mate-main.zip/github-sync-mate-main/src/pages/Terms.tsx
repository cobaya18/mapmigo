import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Terms() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center gap-4">
          <Link to="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-xl font-semibold">Terms of Service</h1>
        </div>
      </header>
      
      <main className="max-w-3xl mx-auto px-4 py-8 prose prose-neutral dark:prose-invert">
        <p className="text-muted-foreground">Last updated: December 2024</p>
        
        <h2>Acceptance of Terms</h2>
        <p>
          By accessing and using MapMigo, you accept and agree to be bound by these Terms of Service.
        </p>
        
        <h2>Use of Service</h2>
        <p>MapMigo provides a platform for discovering places in Puerto Rico. You agree to:</p>
        <ul>
          <li>Use the service for lawful purposes only</li>
          <li>Provide accurate information when creating an account</li>
          <li>Not attempt to compromise the security of the service</li>
        </ul>
        
        <h2>User Content</h2>
        <p>
          Any places you save are for your personal use. We reserve the right to 
          modify or discontinue features at any time.
        </p>
        
        <h2>Disclaimer</h2>
        <p>
          MapMigo is provided "as is" without warranties of any kind. Place information 
          may not always be accurate or up to date. Always verify details before visiting.
        </p>
        
        <h2>Limitation of Liability</h2>
        <p>
          MapMigo shall not be liable for any indirect, incidental, or consequential 
          damages arising from your use of the service.
        </p>
        
        <h2>Contact</h2>
        <p>
          For questions about these Terms, contact us at legal@mapmigo.com
        </p>
      </main>
    </div>
  );
}
