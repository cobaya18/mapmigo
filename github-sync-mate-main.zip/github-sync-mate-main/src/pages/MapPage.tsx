import { useState, useEffect, useCallback, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Header } from '@/components/layout/Header';
import { FiltersSidebar } from '@/components/filters/FiltersSidebar';
import { MapView } from '@/components/map/MapView';
import { SavedPanel } from '@/components/saved/SavedPanel';
import { PlacesListPanel } from '@/components/places/PlacesListPanel';
import { AccountPanel } from '@/components/account/AccountPanel';
import { useLocations } from '@/hooks/useLocations';
import { Location } from '@/types/location';
import { getCategoryBySlug } from '@/lib/categoryConfig';

const MapPage = () => {
  const { category: categorySlug } = useParams<{ category?: string }>();
  const navigate = useNavigate();
  
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [savedPanelOpen, setSavedPanelOpen] = useState(false);
  const [listPanelOpen, setListPanelOpen] = useState(false);
  const [accountPanelOpen, setAccountPanelOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<string[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);

  // Handle URL-based category filtering
  useEffect(() => {
    if (categorySlug) {
      const category = getCategoryBySlug(categorySlug);
      if (category) {
        setSelectedCategories([category]);
      } else {
        // Invalid category slug, redirect to main map
        navigate('/puerto-rico', { replace: true });
      }
    }
  }, [categorySlug, navigate]);

  const { locations } = useLocations({
    searchQuery,
    selectedCategories,
    selectedRegions,
  });

  const handleViewToggle = useCallback(() => {
    setListPanelOpen(prev => !prev);
    setSavedPanelOpen(false);
    setAccountPanelOpen(false);
  }, []);

  const handleSavedToggle = useCallback(() => {
    setSavedPanelOpen(prev => !prev);
    setListPanelOpen(false);
    setAccountPanelOpen(false);
  }, []);

  const handleAccountToggle = useCallback(() => {
    setAccountPanelOpen(prev => !prev);
    setSavedPanelOpen(false);
    setListPanelOpen(false);
  }, []);

  const handleSidebarToggle = useCallback(() => {
    setSidebarOpen(prev => !prev);
  }, []);

  const handleSidebarClose = useCallback(() => {
    setSidebarOpen(false);
  }, []);

  // Memoize the right overlay width calculation
  const rightOverlayWidth = useMemo(() => 
    listPanelOpen ? 420 : savedPanelOpen || accountPanelOpen ? 384 : 0,
    [listPanelOpen, savedPanelOpen, accountPanelOpen]
  );

  return (
    <div className="h-screen w-screen overflow-hidden bg-background">
      <Header
        onMenuToggle={handleSidebarToggle}
        onViewToggle={handleViewToggle}
        onSavedToggle={handleSavedToggle}
        onAccountToggle={handleAccountToggle}
        isListView={listPanelOpen}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        locations={locations}
        onLocationSelect={setSelectedLocation}
      />

      {/* Sidebar - now overlays the map */}
      <div
        className={cn(
          'fixed top-14 left-0 bottom-0 w-96 z-40 bg-sidebar border-r border-sidebar-border transition-transform duration-300',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <FiltersSidebar
          isOpen={sidebarOpen}
          onClose={handleSidebarClose}
          selectedCategories={selectedCategories}
          onCategoryChange={setSelectedCategories}
          selectedRegions={selectedRegions}
          onRegionChange={setSelectedRegions}
          locationCount={locations.length}
        />
      </div>

      {/* Overlay for mobile sidebar */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={handleSidebarClose}
        />
      )}

       {/* Map container - now always full width */}
       <div
         className="absolute top-14 left-0 right-0 bottom-0"
         id="map-wrapper"
       >
         <MapView
           locations={locations}
           selectedLocation={selectedLocation}
           onLocationSelect={setSelectedLocation}
           sidebarOpen={sidebarOpen}
           rightOverlayWidth={rightOverlayWidth}
           topOverlayHeight={56}
         />
       </div>

      {/* Saved Panel */}
      <SavedPanel 
        open={savedPanelOpen} 
        onClose={handleSavedToggle}
        onPlaceClick={setSelectedLocation}
      />

      {/* List View Panel */}
      <PlacesListPanel
        open={listPanelOpen}
        onClose={handleViewToggle}
        locations={locations}
        onPlaceClick={setSelectedLocation}
      />

      {/* Account Panel */}
      <AccountPanel
        open={accountPanelOpen}
        onClose={handleAccountToggle}
      />
    </div>
  );
};

export default MapPage;
