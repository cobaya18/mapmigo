import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { MapPin, ArrowUpRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { categoryConfig } from '@/lib/categoryConfig';
import prFlag from '@/assets/flag-puerto-rico.png';

interface PlaceImage {
  image_url: string;
  image_credit: string | null;
  title: string;
}

const Landing = () => {
  const [images, setImages] = useState<PlaceImage[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch random images from database
  useEffect(() => {
    const fetchImages = async () => {
      const { data, error } = await supabase
        .from('places')
        .select('image_url, image_credit, title')
        .not('image_url', 'is', null)
        .limit(15);

      if (!error && data) {
        const shuffled = data
          .filter(p => p.image_url)
          .sort(() => Math.random() - 0.5) as PlaceImage[];
        setImages(shuffled);
      }
      setIsLoading(false);
    };

    fetchImages();
  }, []);

  // Rotate images every 5 seconds
  useEffect(() => {
    if (images.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentIndex(prev => (prev + 1) % images.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [images.length]);

  const currentImage = images[currentIndex];

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 h-14 bg-background/80 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between h-full px-4 max-w-7xl mx-auto">
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            <div>
              <span className="font-semibold text-foreground">MapMigo</span>
              <p className="text-xs text-muted-foreground hidden sm:block">Your map amigo for real-world exploring.</p>
            </div>
          </div>
          <Link to="/puerto-rico">
            <Button size="sm" className="gap-1.5">
              Open Puerto Rico map
              <ArrowUpRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </header>

      {/* Background Image Carousel */}
      {images.map((image, index) => (
        <div
          key={image.image_url}
          className="absolute inset-0 transition-opacity duration-1000"
          style={{
            opacity: index === currentIndex ? 1 : 0,
            zIndex: 0,
          }}
        >
          <img
            src={image.image_url}
            alt={image.title}
            className="h-full w-full object-cover"
          />
        </div>
      ))}

      {/* Content Card */}
      <div className="relative z-20 flex items-center justify-center min-h-screen px-4 py-20">
        <div className="bg-background/95 backdrop-blur-md rounded-2xl shadow-2xl p-8 max-w-2xl w-full">
          {/* Tagline with PR Flag */}
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-muted rounded-full text-sm mb-6">
            <img src={prFlag} alt="Puerto Rico flag" className="h-4 w-auto" />
            <span className="text-muted-foreground">Built map-first for Puerto Rico.</span>
          </div>

          {/* Headline */}
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4 leading-tight">
            Rediscover home on a cleaner map.
          </h1>

          {/* Description */}
          <p className="text-muted-foreground mb-6 leading-relaxed">
            MapMigo is a map amigo for locals and visitors who are tired of clutter, tabs, blogs, and feeds. Explore{' '}
            <span className="font-semibold text-foreground">beaches, hikes, rivers, viewpoints, museums, nightlife</span>{' '}
            and more in one focused, fast map for Puerto Rico.
          </p>

          {/* CTA Row */}
          <div className="flex flex-wrap items-center gap-4 mb-8">
            <Link to="/puerto-rico">
              <Button size="lg" className="gap-2">
                Open Puerto Rico map
                <span className="text-lg">🌴</span>
              </Button>
            </Link>
            <p className="text-sm text-muted-foreground">
              <span className="text-primary">✨</span> No clutter. Just places worth going.
            </p>
          </div>

          {/* Explore by vibe */}
          <div className="mb-6">
            <p className="text-sm font-medium text-foreground mb-3">Explore by vibe:</p>
            <div className="flex flex-wrap gap-2">
              {categoryConfig.map((route) => (
                <Link
                  key={route.slug}
                  to={`/${route.slug}`}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-muted hover:bg-muted/80 border border-border rounded-full text-sm text-foreground transition-colors"
                >
                  <span>{route.icon}</span>
                  <span>{route.label}</span>
                </Link>
              ))}
            </div>
          </div>

          {/* Feature bullets */}
          <div className="flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="text-primary">📍</span> Hand-picked places across the island.
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-primary">💻</span> Map-first experience for phone and desktop.
            </span>
            <span className="flex items-center gap-1.5">
              <span className="text-primary">🚗</span> Designed for road trips and spotty service.
            </span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="absolute bottom-0 left-0 right-0 z-30 flex items-center justify-between px-4 py-3 text-xs text-white/70 bg-black/30">
        <div className="flex items-center gap-4">
          {currentImage?.image_credit && (
            <span>{currentImage.image_credit}</span>
          )}
        </div>
        <div className="flex items-center gap-4">
          <Link to="/privacy" className="hover:text-white transition-colors">Privacy</Link>
          <Link to="/terms" className="hover:text-white transition-colors">Terms</Link>
          <span>© 2026 MapMigo</span>
        </div>
      </div>
    </div>
  );
};

export default Landing;
